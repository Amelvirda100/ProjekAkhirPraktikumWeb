

  <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="styleberanda.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
    
    <div class="container text-center " >
        <div class="row align-items-center">
          
          <div class="fContainer" >
            <nav class="wrapper"> 
                <div class="brand">
                    <div class="firstname">Puskesmas</div>
                    <div class="lastname">Babarsari </div>
                </div>
                <ul class="navigation">
                    <li><a href="/">home</a></li>
                    <li><a href="login.php">login</a></li>
                    <li><a href="alur.html">alur pelayanan</a></li>
                    <li><a href="kontak.html">kontak</a></li>
                </ul>
            </nav>
        </div>
        

            
          <div class="col">
            <tr>
              <a class="btn btn-success disabled placeholder col-4" aria-disabled="true" style="width: 400px;"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-newspaper" viewBox="0 0 16 16">
                <path d="M0 2.5A1.5 1.5 0 0 1 1.5 1h11A1.5 1.5 0 0 1 14 2.5v10.528c0 .3-.05.654-.238.972h.738a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 1 1 0v9a1.5 1.5 0 0 1-1.5 1.5H1.497A1.497 1.497 0 0 1 0 13.5zM12 14c.37 0 .654-.211.853-.441.092-.106.147-.279.147-.531V2.5a.5.5 0 0 0-.5-.5h-11a.5.5 0 0 0-.5.5v11c0 .278.223.5.497.5z"/>
                <path d="M2 3h10v2H2zm0 3h4v3H2zm0 4h4v1H2zm0 2h4v1H2zm5-6h2v1H7zm3 0h2v1h-2zM7 8h2v1H7zm3 0h2v1h-2zm-3 2h2v1H7zm3 0h2v1h-2zm-3 2h2v1H7zm3 0h2v1h-2z"/>
              </svg>       <i class="bi bi-newspaper">BERITA TERKINI</i></a>   
            </tr>
            <br><br><br>

            <table>
            <tr> 
              <a href="https://www.detik.com/sumbagsel/berita/d-6845623/waspada-hepatitis-satu-kehidupan-satu-hati">
                <img src="berita1.jpg" alt="berita1" style="width: 200px; border-radius: 10px">
              </a>
              
                 <h2 style=" font-size: 20px; color: rgb(23, 98, 23);">Waspada Hepatitis, Satu Kehidupan Satu Hati</h2>
                 
            </tr>
            <br>
            <tr><a href="https://pkmjuli2.bireuenkab.go.id/berita/kategori/kesehatan/edukasi-kesehatan-jantung-oleh-dr-intan-minofa-di-uptd-puskesmas-juli-2">
              <img src="berita2.jpg" alt="berita1" style="width: 200px; border-radius: 10px">
              </a>
               <h2 style=" font-size: 20px; color: rgb(23, 98, 23);">Edukasi Kesehatan Jantung oleh dr. Intan Minofa di UPTD Puskesmas Juli-2</h2>
              </tr>
              <br>
            <tr><a href="https://pontas.id/2021/09/26/lantik-puluhan-kepala-puskesmas-ini-4-pesan-bupati-sergai/">
              <img src="berita3.jpg" alt="berita1" style="width: 200px; border-radius: 10px">
               </a>
               <h2 style=" font-size: 20px; color: rgb(23, 98, 23);">Lantik Puluhan Kepala Puskesmas, Ini 4 Pesan Bupati Serga</h2>
            </tr>
            <br>
            <tr><a href=https://warta.jogjakota.go.id/detail/index/28775>
                <img src="berita4.jpg" alt="berita1" style="width: 200px; border-radius: 10px">
                 </a>
                 <h2 style=" font-size: 20px; color: rgb(23, 98, 23);">Tingkatkan Kualitas Layanan, Puskesmas di Kota Yogya Targetkan Akreditasi Paripurna</h2>
            </tr>
            <br>
            <tr><a href="https://warta.jogjakota.go.id/detail/index/30385">
              <img src="berita5.jpg" alt="berita1" style="width: 200px; border-radius: 10px" >
               </a>
               <h2 style=" font-size: 20px; color: rgb(23, 98, 23);">Vaksinasi Rabies Kembali Digelar di Kelurahan</h2>
          </tr>
          <br>
          <tr><a href="https://megapolitan.kompas.com/read/2023/11/23/11332271/ada-41-anak-stunting-di-bungur-puskesmas-lakukan-pemeriksaan-secara">
            <img src="berita6.jpeg" alt="berita1" style="width: 200px; border-radius: 10px">
             </a>
             <h2 style=" font-size: 20px; color: rgb(23, 98, 23);">Ada 41 Anak "Stunting" di Bungur, Puskesmas Lakukan Pemeriksaan secara Menyeluruh</h2>
        </tr>
        </table>
        <br><br><br><br><br><br><br><br><br><br><br>
          </div>

  
          <div class="col" style=" background-color: rgba(240, 240, 240, 0.675); height: max-width;">
         
            <br><h1 style="font-size: 30px; color: forestgreen; ">Selamat datang di website resmi Puskesmas Babarsari!</h1>
           
            <p>Kami dengan gembira menyambut Anda di halaman online Puskesmas Babarsari. Sebagai pusat pelayanan kesehatan yang berdedikasi, Puskesmas Babarsari hadir untuk memberikan layanan kesehatan terbaik bagi masyarakat.

                Di sini, Anda dapat menemukan informasi lengkap seputar layanan kesehatan yang kami sediakan, jadwal praktek dokter, program kesehatan masyarakat, dan berbagai informasi penting lainnya. Kami berkomitmen untuk menyediakan informasi yang jelas dan akurat guna mendukung Anda dalam menjaga kesehatan diri dan keluarga.
                
                
         <br><br> Selamat menjelajahi setiap halaman website kami. Temukan layanan yang sesuai dengan kebutuhan Anda, dan jangan ragu untuk menghubungi kami jika Anda memiliki pertanyaan atau butuh bantuan. Kami selalu siap membantu Anda dengan senang hati.
                
                Terima kasih atas kunjungan Anda di website Puskesmas Babarsari. Semoga informasi yang kami sajikan dapat memberikan manfaat dan membantu Anda dalam menjaga kesehatan dengan baik.
                
                Salam sehat,
                Puskesmas Babarsari</p>
                <h1 style="font-size: 30px; color: forestgreen; ">Sejarah Puskesmas</h1>
                <p>Pada tanggal 10 Oktober 1998, Puskesmas Babarsari resmi didirikan sebagai wujud komitmen pemerintah dalam menyediakan layanan kesehatan yang berkualitas bagi masyarakat di sekitar wilayah tersebut. Berawal dari kesadaran akan pentingnya akses mudah dan cepat terhadap pelayanan kesehatan, pendirian Puskesmas ini didorong oleh upaya untuk meningkatkan status kesehatan masyarakat secara menyeluruh.
                  <br><br>

                    Proses pendirian Puskesmas ini melibatkan kerjasama antara pemerintah daerah, tenaga kesehatan, dan berbagai pihak yang peduli terhadap kesejahteraan masyarakat. Melalui perencanaan yang matang dan partisipasi aktif dari berbagai pihak, Puskesmas Babarsari diresmikan dengan tujuan utama untuk memberikan pelayanan kesehatan preventif, promotif, kuratif, dan rehabilitatif.
                    
                    <br><br>Sejak saat itu, Puskesmas Babarsari terus tumbuh dan berkembang, menyesuaikan diri dengan perkembangan kebutuhan kesehatan masyarakat. Dengan dukungan sumber daya manusia yang berkualitas dan fasilitas yang memadai, Puskesmas ini berkomitmen untuk menjadi pusat kesehatan yang terdepan dalam memberikan layanan yang berfokus pada upaya pencegahan penyakit, peningkatan kesehatan ibu dan anak, serta pemberdayaan masyarakat dalam mengelola kesehatan mereka.
                    
                    
                    <br><br>Selama perjalanan sejarahnya, Puskesmas Babarsari terus berupaya untuk meningkatkan mutu layanan dan merespons dinamika kebutuhan kesehatan masyarakat. Seiring berjalannya waktu, tanggal 10 Oktober menjadi momen bersejarah yang selalu diingat sebagai awal perjalanan Puskesmas ini dalam memberikan kontribusi nyata untuk kesejahteraan masyarakat setempat.</p>
          </div>
            <div class="col">
              <tr>
                <a class="btn btn-success-border-subtle disabled placeholder col-4" aria-disabled="true" style="width: 400px;">   
                      <i class="bi bi-newspaper">Kegiatan Kami</i></a>   
              </tr>
              <br><br><br>
                  <tr>
                        <td><img src="kegiatan1.jpeg" alt="kegiatan" style="width: 150px; float: left; border-radius: 10px;"></td>
                        <td><h2 style="font-size: 20px;">Puskesmas Babarsari Kedatangan Mahasiswa KKN dari UNY</h2></td>
                  </tr>
                  <br><br><br>
                      <tr>
                        <td><img src="kegiatan2.jpeg" alt="kegiatan" style="width: 150px; float: left; border-radius: 10px;"></td>
                        <td><h2 style="font-size: 20px; ;" >Puskesmas Babarsari Mengadakan Senam Bersama</h2></td>
                        <br>
                      </tr>
                    <br><br>
                          <tr>
                            <td><img src="kegiatan3.jpg" alt="kegiatan" style="width: 150px; float: left; border-radius: 10px;"></td>
                            <td><h2 style="font-size: 20px;">Bupati Sleman Berkunjung ke Puskesmas Babarsari</h2></td>

                          </tr>
                      <br><br><br><br>
                      <tr>
                        <td><img src="kegiatan4.png" alt="kegiatan" style="width: 150px; float: left; border-radius: 10px;"></td>
                        <td><h2 style="font-size: 20px;">Kegiatan Sosialisasi Kompetensi Kader Bagi Puskesmas</h2></td>

                      </tr>
                      <br><br><br><br>
                      <tr>
                        <td><img src="kegiatan5.jpg" alt="kegiatan" style="width: 150px; float: left; border-radius: 10px;"></td>
                        <td><h2 style="font-size: 20px;">Sosialisasi Kesehatan Masyarakat di Era New Normal</h2></td>

                      </tr>
                    <br> <br> <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            </div>
        </div>
        
            <div class="bContainer" >
              <nav class="bwrapper"> 
              </nav>
          </div>
          <div class="footerContainer">
            <div class="footerNav"> 
              
            </div>
            
              <p>Copyright &copy;2023; Designed by <span class="designer">Malik, Virda, Dimas</span></p>
          </div> 
      </div>
      
    
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>