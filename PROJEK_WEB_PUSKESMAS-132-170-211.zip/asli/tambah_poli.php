<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="style1.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark " style="padding-bottom: 10px; font-family: Fjalla One;
        font-size: 115%;">
            <h1 class="nav1">PUSKESMAS BABARSARI</h1>
        </nav>  
     
           <div class="sidebar">
                <header>Menu</header>
                    <ul>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-plus"></i> Pasien</li></a>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-user-doctor"></i> Dokter</li></a>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-house-chimney-medical"></i> Poli</li></a>
                    </ul>
    
            </div>
    <div class="container " style="width: 500px; margin-top: 150px; 
    padding-left: 5px; padding-right: 5px; padding-bottom: 5px; border: 2px green solid; margin-right:350px; margin-top:100px;">

        <h1 class="btn-success" style="font-family:baufra; font-size: 29px; width: 497px; margin-left: -5px; text-align: center; ">TAMBAH DATA</h1>

        <form method="POST" action="tambah_poli_proses.php" >
            <div class="form-group" >
                <label for="id">Nama Poli</label>
                <input type="text"  id="id" name="nama_poli" required >
            </div>

            <div class="form-group">
                <label for="name">Ruang Poli</label>
                <input type="text" id="name" name="ruang_poli" required>
            </div>

         

            <div class="row justify-content-center">
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fa-regular fa-floppy-disk"></i> Simpan Data</button>
                </div>
                <div class="col-md-4">
                    <a href="poli.php" class="btn btn-danger btn-block"><i class="fa-solid fa-rotate-left"></i> Kembali</a>
                </div>
            </div>
        </form>
    </div>

   

 
    </script>
</body>
</html>
