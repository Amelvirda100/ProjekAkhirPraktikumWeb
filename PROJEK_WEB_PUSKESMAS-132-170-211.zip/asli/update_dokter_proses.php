<?php 
	include 'koneksi.php';

	$id	= $_POST['id_dokter'];
	$nama_dokter	= $_POST['nama_dokter'];
    $jenis_kelamin	= $_POST['jenis_kelamin'];
    $no_induk		= $_POST['no_induk'];
	$tempat_lhr		= $_POST['tempat_lhr'];
	$tgl_lhr		= $_POST['tgl_lhr'];
    $alamat			= $_POST['alamat'];
  

    $query = mysqli_query($konek, "UPDATE dokter SET nama_dokter='$nama_dokter', 
    jenis_kelamin='$jenis_kelamin', no_induk='$no_induk', tempat_lhr='$tempat_lhr', tgl_lhr='$tgl_lhr', alamat='$alamat' 
	WHERE id_dokter='$id'");

	if ($query) {
		header("location: dokter.php");
	}
	else {
		echo "maaf input gagal";
	}
?>


