<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <title>Login</title>
</head>
<body>
  <center>
    <img src="logo.png" alt="logo" style="width: 100px;  height: auto">
    <div class="container text-center">
      <h2 style="font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">Puskesmas Babarsari</h2>
      <p>Silahkan Login Menggunakan Username dan Password</p>
      <!-- Form login -->
      <form action="pasien.php" method="post">
        <!-- Form input -->
        <div class="form-group">
          <label for="username">Username:</label>
          <input type="text" class="form-control" id="username" name="username" style="width: 575px; text-align: center;" required>
        </div>
        
        <div class="form-group">
          <label for="password">Password:</label>
          <input type="password" class="form-control" id="password" name="password" style="width: 575px; text-align: center;" required>
        </div>
        <!-- Tombol submit -->
        <button type="submit" class="btn btn-success">Login</button>
      </form>

      <!-- Tombol Back ke beranda.php -->
      <div class="row justify-content-center mt-3">
        <div class="col-auto">
          <a href="beranda.php" class="btn btn-secondary">Back to Beranda</a>
        </div>
      </div>
    </div>
  </center>

  <!-- Bootstrap JS (optional) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
