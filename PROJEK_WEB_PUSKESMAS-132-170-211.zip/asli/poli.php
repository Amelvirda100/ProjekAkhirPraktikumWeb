<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="styleee.css">
    <script src="https://kit.fontawesome.com/ae41e32e70.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>

  <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark" style="padding-bottom: 10px; font-family:baufra ;">
        <h1 class="nav1">PUSKESMAS BABARSARI</h1>
        </nav>  
 
       <div class="sidebar">
            <header>Menu</header>
                <ul>
                    <li type="button"><a href="pasien.php" style="text-decoration: none; color: white;"><i class="fa-solid fa-plus"></i> Pasien</li></a>
                    <li type="button"><a href="dokter.php" style="text-decoration: none; color: white;"><i class="fa-solid fa-user-doctor"></i> Dokter</li></a>
                    <li type="button"><a href="#" style="text-decoration: none; color: white;"></a><i class="fa-solid fa-house-chimney-medical"></i> Poli</li>
                </ul>

        </div>

        <div id="layoutSidenav_content">
          <main>
              <div class="container-fluid">
                  <h1 class="mt-4">Data Poli</h1>
                  <div class="card mb-4">
                      <div class="card-header">
                          <!-- Button trigger modal -->
                         <a href="tambah_poli.php"> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#hpmodal">
                              Tambah Data
                          </button></a>
                        <a href="logout.php"><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hpmodal"></a>
                            Logout
                        </button></a>
                      </div>
                      <div class="card-body">
                          <div class="table-responsive">
                              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center;">
                                  <thead>
                                      <tr>
                                          <th>Nomor</th>
                                          <th>Nama Poli</th>
                                          <th>Ruang Poli</th>
                                          <th>Action</th>
                                      </tr>
                                  </thead>


                                  <tbody>
                                  <?php 
                                        include 'koneksi.php';
                                        $nomor = 1;

                                        $query = mysqli_query($konek, "SELECT * FROM poli");

                                        while ($data = mysqli_fetch_array($query)) { ?>
                                            <tr>
                                                <td><?= $nomor?></td>
                                                <td><?= $data['nama_poli']; ?></td>
                                                <td><?= $data['ruang_poli']; ?></td>

                                                
                                                
                                                <td>
                                                <a href="update_poli.php?id_poli=<?= $data['id_poli']; ?>"><button style="margin: 2px;" type="button" class="btn btn-warning bg-transparent text-warning" >Update</button></a>
                                                <a href="hapus_poli.php?id_poli=<?= $data['id_poli']; ?>"><button style="margin: 2px;" type="button" class="btn btn-danger bg-transparent text-danger" >Delete</button></a>
                                                </td>
                                          </tr>
                                          </tr>
                                        <?php $nomor++; }
                                    ?>
        

                                          
      
           
                                            
                                                

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>