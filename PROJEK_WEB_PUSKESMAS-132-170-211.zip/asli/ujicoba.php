<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <title>Login</title>
</head>
<body>
    <center>
    <img src="logo.png" alt="logo" style="width: 100px;  height: auto">
  <div class="container">
    <div>
    <h2 style="font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;">Puskesmas Babarsari</h2>
    <p>
        Silahkan Login Menggunakan Username dan Password
    </p>
    
        <?php
        if (isset($_GET['pesan'])) {
            if ($_GET['pesan'] == "gagal") {
                echo "Login gagal! username dan password salah!";
            } else if ($_GET['pesan'] == "logout") {
                echo "Anda telah berhasil logout";
            } else if ($_GET['pesan'] == "belum_login") {
                echo "Anda harus login untuk mengakses halaman admin";
            }
        }
        ?>
      
    <!-- Form login -->
    <form action="pasien.html" method="post">
      <!-- Form input -->
      <div class="form-group" >
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username" style="width: 500px;" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" style="width: 500px;" required>
      </div>
      <!-- Tombol submit -->
      
      <button type="submit" class="btn btn-success">Login</button>
      
    </form>
  </div>

</center>
  <!-- Bootstrap JS (optional) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>