<?php 
	include 'koneksi.php';

    $id = $_POST['id_poli'];
	$nama_poli	= $_POST['nama_poli'];
	$ruang_poli	= $_POST['ruang_poli'];
	
	$query = mysqli_query($konek, "UPDATE poli SET nama_poli='$nama_poli', ruang_poli='$ruang_poli' WHERE id_poli='$id'");

	if ($query) {
		header("location: poli.php");
	}
	else {
		echo "maaf input gagal";
	}
?>


