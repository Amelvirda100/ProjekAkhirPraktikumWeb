<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="style1.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark " style="padding-bottom: 10px; font-family: Fjalla One;
        font-size: 115%;">
            <h1 class="nav1">PUSKESMAS BABARSARI</h1>
        </nav>  
     
           <div class="sidebar">
                <header>Menu</header>
                    <ul>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-plus"></i> Pasien</li></a>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-user-doctor"></i> Dokter</li></a>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-house-chimney-medical"></i> Poli</li></a>
                    </ul>
    
            </div>
        <div class="container " style="width: 500px; margin-top: 150px; 
        padding-left: 5px; padding-right: 5px; padding-bottom: 5px; border: 2px green solid; margin-right:350px; margin-top:100px;">

        <h1 class="btn-success" style="font-family:baufra; font-size: 29px; width: 497px; margin-left: -5px; text-align: center; ">TAMBAH DATA</h1>

        <form method="POST" action="tambah_pasien_proses.php">

            <div class="form-group">
                <label for="name">No KTP</label>
                <input type="text" id="name" name="no_ktp" >
            </div>

            <div class="form-group">
                <label for="name">No BPJS</label>
                <input type="text" id="name" name="no_bpjs" >
            </div>

            <div class="form-group">
                <label for="name">Nama Pasien</label>
                <input type="text" id="name" name="nama_pasien" >
            </div>

            <div class="form-group">
            <label for="name">Jenis Kelamin</label>
                <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki-laki" value="L" >
                <label class="form-check-label" for="laki-laki"> 
                 Laki-laki
                
                </label><br>

                <input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="P"  
                style="margin-left:85px">
                <label class="form-check-label" for="perempuan" style="margin-left: 100px;">
                Perempuan
                 </label>
            </label>
            </div>

            <div class="form-group">
                <label for="name">Tempat Lahir</label>
                <input type="text" id="name" name="tempat_lahir" >
            </div>

            <div class="form-group">
            <label for="tanggal_lahir">Tanggal Lahir</label>
            <input type="date" id="tanggal_lahir" name="tanggal_lahir" >
            </div>


            <div class="form-group">
                <label for="name">Alamat</label>
                <input type="text" id="name" name="alamat" >
            </div>

            <div class="form-group">
                <label for="name">Status Pasien</label>
                <input type="text" id="name" name="status_pasien" >
            </div>
         

            <div class="row justify-content-center">
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fa-regular fa-floppy-disk"></i> Simpan Data</button>
                </div>
                <div class="col-md-4">
                    <a href="pasien.php" class="btn btn-danger btn-block"><i class="fa-solid fa-rotate-left"></i> Kembali</a>
                </div>
            </div>
        </form>
    </div>

   

 
    </script>
</body>
</html>
