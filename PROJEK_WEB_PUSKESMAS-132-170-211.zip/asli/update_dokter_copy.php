<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="style1.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php 
			include 'koneksi.php';

			$id_dokter = $_GET['id_dokter'];

			$query = mysqli_query($konek, "SELECT * FROM dokter WHERE id_dokter='$id_dokter'");
			$data = mysqli_fetch_array($query);
		?>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark " style="padding-bottom: 10px; font-family: Fjalla One;
        font-size: 115%;">
            <h1 class="nav1">PUSKESMAS BABARSARI</h1>
        </nav>  
     
           <div class="sidebar">
                <header>Menu</header>
                    <ul>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-plus"></i> Pasien</li></a>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-user-doctor"></i> Dokter</li></a>
                        <li type="button"><a href="#"></a><i class="fa-solid fa-house-chimney-medical"></i> Poli</li></a>
                    </ul>
    
            </div>
        <div class="container " style="width: 500px; margin-top: 150px; 
        padding-left: 5px; padding-right: 5px; padding-bottom: 5px; border: 2px green solid; margin-right:300px; margin-top:90px; ">

        <h1 class="btn-success" style="font-family:baufra; font-size: 29px; width: 497px; margin-left: -5px; text-align: center; ">UPDATE DATA</h1>

        <form id="updateForm" method="POST" action="update_dokter_proses.php">
        <div class="form-group" hidden >
                <label for="id">Kode Dokter</label>
                <input type="text" id="name" name="id_dokter" value="<?= $data['id_dokter']; ?>">
            </div>

            <div class="form-group">
                <label for="name">Nama Dokter</label>
                <input type="text" id="name" name="nama_dokter" value="<?= $data['nama_dokter']; ?>" >
            </div>

            <div class="form-group">
            <label for="name">Jenis Kelamin</label>
                <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki-laki" value="L" >
                <label class="form-check-label" for="laki-laki">
                 Laki-laki
                </label>
                <input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="P" >
                <label class="form-check-label" for="perempuan">
                Perempuan
                 </label>
            </label>
            </div>

            <div class="form-group">
                <label for="name">Nomer Induk Dokter</label>
                <input type="text" id="name" name="no_induk" values="<?= $data['no_induk']; ?>" >
            </div>

            <div class="form-group">
                <label for="name">Tempat Lahir</label>
                <input type="text" id="name" name="tempat_lhr" values="<?= $data['tempat_lhr']; ?>" >
            </div>

            <div class="form-group">
             <label for="name">Tanggal Lahir</label>
                <input type="date" name="tgl_lhr" value="<?php $tgl_lhr; ?>">
            </div>


            <div class="form-group">
                <label for="name">Alamat</label>
                 <input type="text" id="name" name="alamat" values="<?= $data['alamat']; ?>">
            </div>

           
         

            <div class="row justify-content-center">
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fa-regular fa-floppy-disk"></i> Simpan Data</button>
                </div>
                <div class="col-md-4">
                    <a href="dokter.php" class="btn btn-danger btn-block"><i class="fa-solid fa-rotate-left"></i> Kembali</a>
                </div>
            </div>
        </form>
    </div>

   

 
    </script>
</body>
</html>
