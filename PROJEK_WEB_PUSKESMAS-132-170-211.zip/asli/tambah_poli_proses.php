
<?php 
	include 'koneksi.php';

	$nama_poli	= $_POST['nama_poli'];
	$ruang_poli	= $_POST['ruang_poli'];
	
	$query = mysqli_query($konek, "INSERT INTO poli VALUES ('', '$nama_poli', '$ruang_poli')");

	if ($query) {
		header("location: poli.php");
	}
	else {
		echo "maaf input gagal";
	}
?>