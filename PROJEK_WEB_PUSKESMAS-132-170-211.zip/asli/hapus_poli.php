<?php 
	include 'koneksi.php';

    $id_poli = $_GET['id_poli'];
	
	$query = mysqli_query($konek, "DELETE FROM poli where id_poli='$id_poli'");

	if ($query) {
		header("location: poli.php");
	}
	else {
		echo "maaf input gagal";
	}
?>


