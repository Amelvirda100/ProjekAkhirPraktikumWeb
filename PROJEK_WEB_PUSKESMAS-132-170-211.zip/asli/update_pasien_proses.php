<?php 
	include 'koneksi.php';

    $id    				= $_POST['id_pasien'];
    $no_ktp 	        = $_POST['no_ktp'];
	$no_bpjs	        = $_POST['no_bpjs'];
	$nama_pasien	    = $_POST['nama_pasien'];
    $jenis_kelamin		= $_POST['jenis_kelamin'];
	$tempat_lahir	    = $_POST['tempat_lahir'];
	$tanggal_lahir		= $_POST['tanggal_lahir'];
    $alamat		        = $_POST['alamat'];
    $status_pasien	    = $_POST['status_pasien'];

	$query = mysqli_query($konek, "UPDATE data_pasien SET no_ktp='$no_ktp', no_bpjs='$no_bpjs', nama_pasien='$nama_pasien', 
    jenis_kelamin='$jenis_kelamin', tempat_lahir='$tempat_lahir', tempat_lahir='$tanggal_lahir', alamat='$alamat',
     status_pasien='$status_pasien' WHERE id_pasien='$id'");

	if ($query) {
		header("location: pasien.php");
	}
	else {
		echo "maaf input gagal";
	}
?>


