<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="styleee.css">
    <script src="https://kit.fontawesome.com/ae41e32e70.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>

  <body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark" style="padding-bottom: 10px;">
        <h1 class="nav1">Puskesmas Babarsari</h1>
    </nav>  
 
       <div class="sidebar">
            <header>Menu</header>
                <ul>
                    <li><i class="fa-solid fa-plus"></i>Pasien</li>
                    <li>Dokter</li>
                    <li>Poli</li>
                </ul>

        </div>

        <div id="layoutSidenav_content">
          <main>
              <div class="container-fluid">
                  <h1 class="mt-4">Stock HP</h1>
                  <div class="card mb-4">
                      <div class="card-header">
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#hpmodal">
                              Tambah Stock
                          </button>
                      </div>
                      <div class="card-body">
                          <div class="table-responsive">
                              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                  <thead>
                                      <tr>
                                          <th>Id</th>
                                          <th>Merk</th>
                                          <th>Tipe</th>
                                          <th>Harga</th>
                                          <th>Stock</th>
                                          <th>Spek</th>
                                          <th>Action</th>
                                      </tr>
                                  </thead>


                                  <tbody>
                                      <?php
                                      $viewhandphone = mysqli_query($conn, "SELECT * FROM `handphone`");
                                      while ($data = mysqli_fetch_array($viewhandphone)) {
                                          $id_hp = $data['id_hp'];
                                          $merk = $data['merk'];
                                          $tipe = $data['tipe'];
                                          $harga = $data['harga_hp'];
                                          $stock = $data['stock_hp'];
                                          $spek = $data['spesifikasi'];

                                      ?>
                                          <tr>
                                              <td><?= $id_hp; ?></td>
                                              <td><?= $merk; ?></td>
                                              <td><?= $tipe; ?></td>
                                              <td><?= "Rp " . $harga; ?></td>
                                              <td><?= $stock ?></td>
                                              <td><?= $spek; ?></td>
                                              <td>
                                                  <button style="margin: 2px;" type="button" class="btn btn-warning" data-toggle="modal" data-target="#modalupdate<?= $id_hp; ?>">Update</button>
                                                  <button style="margin: 2px;" type="button" class="btn btn-danger" data-toggle="modal" data-target="#modaldelete<?= $id_hp; ?>">Delete</button>
                                              </td>
                                          </tr>
        

                                          
      
           
                                            
                                                

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>