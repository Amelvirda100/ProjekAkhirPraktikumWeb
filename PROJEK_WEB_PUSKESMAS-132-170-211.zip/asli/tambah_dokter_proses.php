<?php 
	include 'koneksi.php';

	
	$nama_dokter	= $_POST['nama_dokter'];
    $jenis_kelamin	= $_POST['jenis_kelamin'];
    $no_induk		= $_POST['no_induk'];
	$tempat_lhr		= $_POST['tempat_lhr'];
	$tgl_lhr		= $_POST['tgl_lhr'];
    $alamat			= $_POST['alamat'];
   

	$query = mysqli_query($konek, "INSERT INTO dokter VALUES ('',  '$nama_dokter', 
    '$jenis_kelamin', '$no_induk', '$tempat_lhr', '$tgl_lhr', '$alamat')"); 

	if ($query) {
		header("location: dokter.php");
	}
	else {
		echo "maaf input gagal";
	}
?>