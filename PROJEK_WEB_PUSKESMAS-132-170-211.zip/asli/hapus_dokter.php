<?php 
	include 'koneksi.php';

    $id_dokter = $_GET['id_dokter'];
	
	$query = mysqli_query($konek, "DELETE FROM dokter where id_dokter='$id_dokter'");

	if ($query) {
		header("location: dokter.php");
	}
	else {
		echo "maaf input gagal";
	}
?>


