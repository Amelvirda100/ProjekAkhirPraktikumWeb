
<?php 
	include 'koneksi.php';

	$no_ktp		        = $_POST['no_ktp'];
	$no_bpjs	        = $_POST['no_bpjs'];
	$nama_pasien	    = $_POST['nama_pasien'];
    $jenis_kelamin		= $_POST['jenis_kelamin'];
	$tempat_lahir	    = $_POST['tempat_lahir'];
	$tanggal_lahir		= $_POST['tanggal_lahir'];
    $alamat		        = $_POST['alamat'];
    $status_pasien	    = $_POST['status_pasien'];

	$query = mysqli_query($konek, "INSERT INTO data_pasien VALUES ('', '$no_ktp', '$no_bpjs', '$nama_pasien', 
    '$jenis_kelamin', '$tempat_lahir', '$tanggal_lahir', '$alamat', '$status_pasien')");

	if ($query) {
		header("location: pasien.php");
	}
	else {
		echo "maaf input gagal";
	}
?>