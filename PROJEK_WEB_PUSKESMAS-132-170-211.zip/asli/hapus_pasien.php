<?php 
	include 'koneksi.php';

    $nomor_rekamedis = $_GET['nomor_rekamedis'];
	
	$query = mysqli_query($konek, "DELETE FROM data_pasien where nomor_rekamedis='$nomor_rekamedis'");

	if ($query) {
		header("location: pasien.php");
	}
	else {
		echo "maaf input gagal";
	}
?>


