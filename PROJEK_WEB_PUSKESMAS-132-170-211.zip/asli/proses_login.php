<?php 
   session_start(); 
    // menghubungkan dengan koneksi
    include "koneksi.php";
    
    // menangkap data yang dikirim dari form
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // menyeleksi data admin dengan username dan password yang sesuai
    $data = mysqli_query($konek,"SELECT * FROM user WHERE username='$username' and password='$password'")
            or die (mysqli_error($konek));
    
    // menghitung jumlah data yang ditemukan
    $cek = mysqli_num_rows($data);
    
    if($cek > 0){
        $_SESSION['username'] = $username;
        $_SESSION['status']   = "login";
        header("location:ujicoba.php");
    }else{
        header("location:ujicoba.php?pesan=gagal");
    } 
?>